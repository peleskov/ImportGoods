<?php
/**/
/* For use only in Console */
/**/

/* Важно указать PARENT иначе удалит все рессурсы*/

$products = $modx->getIterator('msProduct', ['parent' => 1]);
foreach($products as $product){
    $dir = MODX_ASSETS_PATH . 'images/products/'.$product->get('id').'/';
    removeDirectory($dir);
    $product->remove();
}

function removeDirectory($dir) {
    if ($objs = glob($dir."/*")) {
        foreach($objs as $obj) {
            is_dir($obj) ? removeDirectory($obj) : unlink($obj);
        }
    }
    rmdir($dir);
}
echo 'Finish!!!';