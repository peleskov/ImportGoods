<?php
$_lang['importgoods'] = 'ImportGoods';
$_lang['importgoods_menu_desc'] = 'A sample Extra to develop from.';
